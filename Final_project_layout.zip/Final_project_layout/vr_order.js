"use strict";

/*
   New Perspectives on HTML5 and CSS3, 7th Edition
   Tutorial 10
   Case Problem 1
  
   Author: 
   Date:   
     
   Filename: tc_order.js  

   The item array contains the ID numbers of the items ordered by the customer
   The itemDescription array contains the description of each item
   The itemPrice array contains the price of each item
   The itemQty array contains the quantity ordered of each item
   
*/

var item = [10582, 23015, 41807, 10041];

var itemDescription = ["Oculus Quest 2 128 GB, Item 10582", "HTC Vive w/ Adaptive triggers, Item 23015", "Playstation VR Headset w/PS5 adapter cable, Item 41807", "HDMI cable, Item 10041"];

var itemPrice = [400.00, 360.00, 450.00, 22.00];

var itemQty = [1, 1, 1, 1];




